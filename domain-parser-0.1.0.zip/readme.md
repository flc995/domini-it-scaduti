![How it works](static/intro.gif)

# Tool di ricerca domini .it scaduti 🕚⚡️

Un semplice script Python per ottenere la lista degli ultimi domini scaduti (massimo ultimi 8 giorni).\
I domini scaduti vengono scaricati dall'anagrafe dei domini italiani (nic.it) attraverso i file messi a disposizione dall'anagrafe stessa
al seguente indirizzo: https://www.nic.it/it/droptime

## Eseguire lo script
```
pip install requirements.txt
python main.py
```